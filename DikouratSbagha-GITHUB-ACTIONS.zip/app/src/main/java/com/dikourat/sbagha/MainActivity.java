package com.dikourat.sbagha;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,int size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(12),dp(8),dp(12),dp(8)); if(bold)t.setTypeface(null,1); return t;
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setBackgroundColor(Color.WHITE);
        TextView head=tv("🎨  Dikourat Sbagha",24,true); head.setTextColor(Color.WHITE); head.setGravity(Gravity.CENTER);
        head.setBackgroundColor(Color.rgb(40,70,110)); page.addView(head,new LinearLayout.LayoutParams(-1,dp(70)));
        LinearLayout buttons=new LinearLayout(this); buttons.setPadding(dp(8),dp(6),dp(8),dp(6));
        Button add=new Button(this); add.setText("＋ إضافة منتوج");
        Button wa=new Button(this); wa.setText("WhatsApp");
        buttons.addView(add,new LinearLayout.LayoutParams(0,dp(55),1)); buttons.addView(wa,new LinearLayout.LayoutParams(0,dp(55),1));
        page.addView(buttons);
        ScrollView sc=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(10),0,dp(10),dp(20)); sc.addView(list); page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        addProduct("FACOP","صباغة ديكور","ثمن البيع: حسب المقاس والكمية");
        addProduct("ATLAS","صباغة ومواد الديكور","ثمن البيع: حسب المنتج");
        add.setOnClickListener(v->showAdd());
        wa.setOnClickListener(v->open("https://wa.me/212"));
        setContentView(page);
    }
    void addProduct(String brand,String name,String price){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(10),dp(12),dp(10)); card.setBackgroundColor(Color.rgb(245,245,245));
        TextView a=tv(brand+" — "+name,20,true); TextView p=tv(price,16,false);
        card.addView(a); card.addView(p); list.addView(card,new LinearLayout.LayoutParams(-1,dp(105)));
        Space sp=new Space(this); list.addView(sp,new LinearLayout.LayoutParams(1,dp(8)));
    }
    void showAdd(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this); n.setHint("اسم المنتوج"); EditText p=new EditText(this); p.setHint("ثمن البيع");
        box.addView(n); box.addView(p);
        new AlertDialog.Builder(this).setTitle("إضافة منتوج").setView(box)
        .setPositiveButton("إضافة",(d,w)->addProduct("منتوج",n.getText().toString(), "ثمن البيع: "+p.getText().toString()+" DH"))
        .setNegativeButton("إلغاء",null).show();
    }
    void open(String u){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception e){} }
}
