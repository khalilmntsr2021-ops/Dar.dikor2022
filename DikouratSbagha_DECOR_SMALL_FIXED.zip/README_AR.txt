تطبيق ديكورات صباغة
====================

المشروع Android WebView باسم: ديكورات صباغة
Package: com.dikourat.sbagha
WhatsApp: 0667775521
Instagram: dar.dikor2022
Facebook: https://www.facebook.com/share/1Bzmaa5RF9/

طريقة إخراج APK:
1) افتح المشروع في Android Studio.
2) انتظر Gradle Sync حتى يكمل.
3) من القائمة: Build > Build APK(s).
4) ستجد APK داخل app/build/outputs/apk/.

لنسخة النشر النهائية، استعمل Build > Generate Signed App Bundle / APK وأنشئ مفتاح توقيع خاص بك.
