@echo off
setlocal
set "GRADLE_VERSION=8.7"
set "INSTALL=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\gradle-%GRADLE_VERSION%"
if not exist "%INSTALL%\bin\gradle.bat" (
  set "ZIP=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin.zip"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName('%ZIP%')) | Out-Null; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' ([IO.Path]::GetDirectoryName('%INSTALL%'))"
)
call "%INSTALL%\bin\gradle.bat" %*
