package com.dikourat.sbagha;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    w.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
        if(url.startsWith("https://wa.me/") || url.startsWith("https://www.facebook.com/") || url.startsWith("https://instagram.com/")){
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; } catch(Exception e){}
        }
        return false;
      }
    });
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.loadUrl("file:///android_asset/index.html"); setContentView(w);
  }
}
