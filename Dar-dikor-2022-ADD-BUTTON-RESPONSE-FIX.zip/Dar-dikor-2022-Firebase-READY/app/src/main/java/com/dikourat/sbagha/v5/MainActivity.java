package com.dikourat.sbagha.v5;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.view.inputmethod.InputType;

public class MainActivity extends Activity {
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private static final int FILE_PICKER = 701;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
        if(url.startsWith("https://wa.me/") || url.startsWith("https://www.facebook.com/") || url.startsWith("https://instagram.com/")){
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; } catch(Exception e){}
        }
        return false;
      }
    });
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("موافق", (d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();
        return true;
      }
      @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("نعم", (d,w)->result.confirm()).setNegativeButton("إلغاء", (d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();
        return true;
      }
      @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        EditText input = new EditText(MainActivity.this);
        input.setSingleLine(true);
        input.setText(defaultValue == null ? "" : defaultValue);
        if(message != null && (message.contains("كلمة السر") || message.toLowerCase().contains("password"))) input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(MainActivity.this).setTitle(message).setView(input)
          .setPositiveButton("موافق", (d,w)->result.confirm(input.getText().toString()))
          .setNegativeButton("إلغاء", (d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();
        return true;
      }
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = callback;
        Intent intent = params.createIntent();
        try { startActivityForResult(intent, FILE_PICKER); }
        catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
        return true;
      }
    });
    WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    webView.loadUrl("file:///android_asset/index.html"); setContentView(webView);
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_PICKER && fileCallback != null) {
      Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
      fileCallback.onReceiveValue(results);
      fileCallback = null;
    }
  }
  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }
}
