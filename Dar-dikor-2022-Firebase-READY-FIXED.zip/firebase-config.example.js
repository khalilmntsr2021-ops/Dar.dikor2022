// Template only — replace values using Firebase Console > Project settings > Your apps.
// Do not put a Firebase Admin SDK service-account private key in the Android app.
window.DAR_DIKOR_FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "dar-dikor-2022.firebaseapp.com",
  projectId: "dar-dikor-2022",
  storageBucket: "PASTE_STORAGE_BUCKET_FROM_CONSOLE",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};
