package com.dikourat.sbagha.v5;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient.FileChooserParams;

public class MainActivity extends Activity {
  private WebView webView;
  private ValueCallback<Uri[]> filePathCallback;
  private static final int FILE_CHOOSER_REQUEST = 501;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url.startsWith("https://wa.me/") || url.startsWith("https://www.facebook.com/") || url.startsWith("https://instagram.com/")) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; } catch (Exception e) { }
        }
        return false;
      }
    });
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("موافق", (d, w) -> result.confirm()).setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
      @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
        new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("نعم", (d, w) -> result.confirm()).setNegativeButton("إلغاء", (d, w) -> result.cancel()).setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
      @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
        input.setSingleLine(true);
        if (defaultValue != null) input.setText(defaultValue);
        new AlertDialog.Builder(MainActivity.this).setTitle(message).setView(input)
          .setPositiveButton("موافق", (d, w) -> result.confirm(input.getText().toString()))
          .setNegativeButton("إلغاء", (d, w) -> result.cancel())
          .setOnCancelListener(d -> result.cancel()).show();
        return true;
      }
      @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        filePathCallback = callback;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try { startActivityForResult(Intent.createChooser(intent, "اختار صورة المنتوج"), FILE_CHOOSER_REQUEST); }
        catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
        return true;
      }
    });
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    webView.loadUrl("file:///android_asset/index.html");
    setContentView(webView);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
      Uri[] results = null;
      if (resultCode == Activity.RESULT_OK && data != null) {
        Uri uri = data.getData();
        if (uri != null) results = new Uri[]{uri};
      }
      filePathCallback.onReceiveValue(results);
      filePathCallback = null;
    }
  }

  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
}
